import HeroSection from "../HeroSection";

function HomePage() {
  return (
    <>
      <HeroSection />
    </>
  );
}

export default HomePage;
